/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ServiceSanPham;

import ModelSanPham.SanPhamChiTiet;
import Repository.Connect;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class QLSanPhamChiTiet {

    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    public ArrayList<SanPhamChiTiet> getAllDao() {
        ArrayList<SanPhamChiTiet> dsspct = new ArrayList<>();
        String sql = "select * from sanphamchitiet";
        try {
            conn = new Connect().getConnectDAO();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                dsspct.add(new SanPhamChiTiet(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8)));
            }
        } catch (Exception e) {
        }
        return dsspct;
    }

    public void add(SanPhamChiTiet spct) {
        String sql = "insert into SanPhamChiTiet values (?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            conn = new Connect().getConnectDAO();
            ps = conn.prepareStatement(sql);
            ps.setString(1, spct.getMa());
            ps.setString(2, spct.getTen());
            ps.setInt(3, spct.getSoLuong());
            ps.setInt(4, spct.getGiaBan());
            ps.setString(5, spct.getSize());
            ps.setString(6, spct.getChatLieu());
            ps.setString(7, spct.getHang());
            ps.setString(8, spct.getTrangThai());
            ps.executeUpdate();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "That bai");
        }
    }

    public void delete(String ma) {
        String sql = "delete sanphamchitiet where masanpham = ?";
        try {
            conn = new Connect().getConnectDAO();
            ps = conn.prepareStatement(sql);
            ps.setString(1, ma);
            ps.executeUpdate();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "That bai");
        }
    }

    public void update(SanPhamChiTiet spct) {
        String sql = "update sanphamchitiet set tensanpham = ?, soluong = ?, giaban = ?, size = ?, chatlieu = ?, hang = ?, trangthai = ? where masanpham = ?";
        try {
            conn = new Connect().getConnectDAO();
            ps = conn.prepareStatement(sql);
            ps.setString(8, spct.getMa());
            ps.setString(1, spct.getTen());
            ps.setInt(2, spct.getSoLuong());
            ps.setInt(3, spct.getGiaBan());
            ps.setString(4, spct.getSize());
            ps.setString(5, spct.getChatLieu());
            ps.setString(6, spct.getHang());
            ps.setString(7, spct.getTrangThai());
            ps.executeUpdate();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "That bai");
        }
    }

    public ArrayList<SanPhamChiTiet> getAllDaoSize(String size) {
        ArrayList<SanPhamChiTiet> dsspct = new ArrayList<>();
        String sql = "select * from sanphamchitiet where size = ?";
        try {
            conn = new Connect().getConnectDAO();
            ps = conn.prepareStatement(sql);
            ps.setString(1, size);
            rs = ps.executeQuery();
            while (rs.next()) {
                dsspct.add(new SanPhamChiTiet(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8)));
            }
        } catch (Exception e) {
        }
        return dsspct;
    }

    public ArrayList<SanPhamChiTiet> getAllDaoChatLieu(String chatLieu) {
        ArrayList<SanPhamChiTiet> dsspct = new ArrayList<>();
        String sql = "select * from sanphamchitiet where chatlieu = ?";
        try {
            conn = new Connect().getConnectDAO();
            ps = conn.prepareStatement(sql);
            ps.setString(1, chatLieu);
            rs = ps.executeQuery();
            while (rs.next()) {
                dsspct.add(new SanPhamChiTiet(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8)));
            }
        } catch (Exception e) {
        }
        return dsspct;
    }

    public ArrayList<SanPhamChiTiet> getAllDaoHang(String hang) {
        ArrayList<SanPhamChiTiet> dsspct = new ArrayList<>();
        String sql = "select * from sanphamchitiet where hang = ?";
        try {
            conn = new Connect().getConnectDAO();
            ps = conn.prepareStatement(sql);
            ps.setString(1, hang);
            rs = ps.executeQuery();
            while (rs.next()) {
                dsspct.add(new SanPhamChiTiet(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8)));
            }
        } catch (Exception e) {
        }
        return dsspct;
    }

    public ArrayList<SanPhamChiTiet> getAllDaoTinhTrang(String tinhTrang) {
        ArrayList<SanPhamChiTiet> dsspct = new ArrayList<>();
        String sql = "select * from sanphamchitiet where trangthai = ?";
        try {
            conn = new Connect().getConnectDAO();
            ps = conn.prepareStatement(sql);
            ps.setString(1, tinhTrang);
            rs = ps.executeQuery();
            while (rs.next()) {
                dsspct.add(new SanPhamChiTiet(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8)));
            }
        } catch (Exception e) {
        }
        return dsspct;
    }

//    public SanPhamChiTiet TimKiem(String ten) {
//        ArrayList<SanPhamChiTiet> dsspct = new ArrayList<>();
//        SanPhamChiTiet spct = null;
//        String sql = "select * from sanphamchitiet where tensanpham like ?";
//        try {
//            conn = new Connect().getConnectDAO();
//            ps = conn.prepareStatement(sql);
//            ps.setString(1, ten);
//            rs = ps.executeQuery();
//            while (rs.next()) {
//                spct = new SanPhamChiTiet(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8));
//            }
//            return spct;
//        } catch (Exception e) {
//            return null;
//        }
    public ArrayList<SanPhamChiTiet> getAllDaoTimKiem(String ten) {
        ArrayList<SanPhamChiTiet> dsspct = new ArrayList<>();
        String sql = "select * from sanphamchitiet where tensanpham like ?";
        try {
            conn = new Connect().getConnectDAO();
            ps = conn.prepareStatement(sql);
            ps.setString(1, "%" + ten + "%");
            rs = ps.executeQuery();
            while (rs.next()) {
                dsspct.add(new SanPhamChiTiet(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8)));
            }
        } catch (Exception e) {
        }
        return dsspct;

    }
}
