/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ServiceSanPham;

import ModelSanPham.SanPham;
import Repository.Connect;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class QlSanPham {

    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    public ArrayList<SanPham> getAllDao() {
        ArrayList<SanPham> dssp = new ArrayList<>();
        String sql = "select * from sanpham";
        try {
            conn = new Connect().getConnectDAO();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                dssp.add(new SanPham(rs.getString(1), rs.getString(2)));
            }
        } catch (Exception e) {
        }
        return dssp;
    }

    public void add(SanPham sp) {
        String sql = "insert into sanpham values (?,?)";
        try {
            conn = new Connect().getConnectDAO();
            ps = conn.prepareStatement(sql);
            ps.setString(1, sp.getMa());
            ps.setString(2, sp.getTen());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Thanh cong");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "That bai");
        }
    }

    public void delete(String ma) {
        String sql = "delete sanpham where masanpham = ?";
        try {
            conn = new Connect().getConnectDAO();
            ps = conn.prepareStatement(sql);
            ps.setString(1, ma);
            ps.executeUpdate();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "That bai");
        }
    }

    public void update(SanPham sp) {
        String sql = "update sanpham set tensanpham = ? where masanpham = ?";
        try {
            conn = new Connect().getConnectDAO();
            ps = conn.prepareStatement(sql);
            ps.setString(2, sp.getMa());
            ps.setString(1, sp.getTen());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Thanh cong");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "That bai");
        }
    }
}
