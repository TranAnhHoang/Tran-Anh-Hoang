/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ModelSanPham;

/**
 *
 * @author tranh
 */
public class TruyenDuLieu {

    public static String ma = "";
    public static String ten = "";

    public TruyenDuLieu() {
    }

    public static String getMa() {
        return ma;
    }

    public static void setMa(String ma) {
        TruyenDuLieu.ma = ma;
    }

    public static String getTen() {
        return ten;
    }

    public static void setTen(String ten) {
        TruyenDuLieu.ten = ten;
    }

}
