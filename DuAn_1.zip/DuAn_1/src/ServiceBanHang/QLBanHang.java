/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ServiceBanHang;

import ModelBanHang.HoaDon;
import ModelBanHang.SanPham;
import Repository.Connect;
import java.sql.*;
import java.util.ArrayList;

public class QLBanHang {

    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    public ArrayList<SanPham> getAllDaoSanPham() {
        ArrayList<SanPham> dssp = new ArrayList<>();
        String sql = "select masanpham, tensanpham, soluong, giaban from sanphamchitiet";
        try {
            Connection conn = new Connect().getConnectDAO();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                dssp.add(new SanPham(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getInt(4)));
            }
        } catch (Exception e) {
        }
        return dssp;
    }

    public void TaoHoaDon(HoaDon hd) {
        String sql = "INSERT INTO HoaDon(maHoaDon, maKhachHang, maNhanVien, ngayBan, trangThai) VALUES\n"
                + "    (CONCAT('HD', FORMAT((SELECT COUNT(*) FROM HoaDon) + 1, '00')),null, 'NV01', ?, 'Cho thanh toan');";
        try {
            Connection conn = new Connect().getConnectDAO();
            ps = conn.prepareStatement(sql);
//            ps.setString(1, hd.getMaHD());
            ps.setString(1, hd.getNgayBan());
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }

    public ArrayList<HoaDon> getAllDaoHoaDon() {
        ArrayList<HoaDon> dshd = new ArrayList<>();
        String sql = "select maHoaDon, tenNhanVien, ngayBan from HoaDon join NhanVien on HoaDon.maNhanVien = NhanVien.maNhanVien where trangThai = 'Cho thanh toan'";
        try {
            Connection conn = new Connect().getConnectDAO();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                dshd.add(new HoaDon(rs.getString(1), rs.getString(2), rs.getString(3)));
            }
        } catch (Exception e) {
        }
        return dshd;
    }

    public void HuyHoaDon(String ma) {
        String sql = "delete from hoadon where mahoadon = ?";
        try {
            Connection conn = new Connect().getConnectDAO();
            ps = conn.prepareStatement(sql);
            ps.setString(1, ma);
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }
}
